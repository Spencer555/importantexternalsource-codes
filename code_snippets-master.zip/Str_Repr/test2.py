a = [1,2,3,4]
b = 'sample string'

print str(a)
print repr(a)

print str(b)
print repr(b)