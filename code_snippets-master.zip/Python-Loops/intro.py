
x = 0

while True:
    # if x == 5:
    #     break
    print(x)
    x += 1
