The Files.py contains all the code snippets shown in
the tutorial. To explicitly use them all through out the video tutorial, make sure to uncomment
them to use it.

In the image section, make sure to use your own image.


Video Link: https://www.youtube.com/watch?v=Uh2ebFW8OYM&t=1295s
