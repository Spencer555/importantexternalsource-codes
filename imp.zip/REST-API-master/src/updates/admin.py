from django.contrib import admin


from .models import Update as UpdateModel


admin.site.register(UpdateModel)