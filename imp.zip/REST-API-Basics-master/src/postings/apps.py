from django.apps import AppConfig


class PostingsConfig(AppConfig):
    name = 'postings'
