1. API Endpoint(s)  uri (url)
    - Retrieve Update Delete
    - Create & List & Search 

    - Permissions???? JWT

2. HTTP methods
    - GET, POST, PUT, PATCH, DELETE

3. Data Types & Validation
    - JSON -> Serializer
    - Validation -> Serializer