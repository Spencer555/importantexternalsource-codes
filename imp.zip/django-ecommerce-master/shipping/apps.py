from django.apps import AppConfig


class ShippingConfig(AppConfig):
    name = 'shipping'
