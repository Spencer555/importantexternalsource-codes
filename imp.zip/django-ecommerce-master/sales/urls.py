from . import views

app_name = 'sales'
urlpatterns = [
]
