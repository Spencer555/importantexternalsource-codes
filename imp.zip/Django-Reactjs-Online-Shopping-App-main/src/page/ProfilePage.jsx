import React from 'react'

const ProfilePage = () => {
    return (
        <div>
            <h1>Profile Page</h1>
        </div>
    )
}

export default ProfilePage
