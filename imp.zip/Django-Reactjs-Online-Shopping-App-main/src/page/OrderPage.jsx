import React from 'react'

const OrderPage = () => {
    return (
        <div>
            <h1>Orders Page</h1>
        </div>
    )
}

export default OrderPage
