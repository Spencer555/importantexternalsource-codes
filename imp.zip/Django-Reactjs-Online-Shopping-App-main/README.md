# 🔥🔥Django Reactjs Online Shopping App🔥🔥

<!-- ### [🔥🔥Part - 0 -  ]() -->

## [See Videos](https://www.youtube.com/playlist?list=PLsC9YeVUTz39OEEoFhHrPNuK62Jcn43yL)
### [🔥🔥Part - 0 - No Code For Part 0](#)
### [🔥🔥Part - 1 - Setup Environment](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/5b700cd7f86f60458a173ea868c4bc3fbb5fa313)
### [🔥🔥Part - 2 - Django Models](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/8c8fb89adb81d4b7b5501c3c6bed570fe8aa0e58)
### [🔥🔥Part - 3 - Category Product API ](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/b17149359ec38fa33ce2b9a9a359c9b5cb76f6c2)
### [🔥🔥Part - 4 - Show Products on Reactjs ](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/175666ec5f3b509c81e39150c97f4ff983f0f0dc)
### [🔥🔥Part - 5 - Single Products on Reactjs](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/52a86e85c21796b72b27fd913f75b3e47d40afa7)
### [🔥🔥Part - 6 - Categories All Products](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/12566a066cf1f9a247b9dc937f8c1eaf929c3613)
### [🔥🔥Part - 7 - Product Details Page](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/cfc76aacbb3f41b3836ac47b8dacd9e4f536c0b6)
### [🔥🔥Part - 8 - Brands Products API ](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/f6f1625933a7491487fef108838f52f34d588fef)
### [🔥🔥Part - 9 - Slider and Trending Products](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/fd3b9213b3212dde2a8c745abbf97e5e9aa98395)
### [🔥🔥Part - 10 - Most Viewed Products](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/988ca7c7a44f5edbe76fb6da93694834e0c9e029)
### [🔥🔥Part - 11 - Add Search Functionality ](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/6afa4a11f398ae9dad04d3b21e0174440e8659e2)
### [🔥🔥Part - 12 - Login by Token ](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/a68c5393a99f6770cc4952ac9d715beb98a36ce0)
### [🔥🔥Part - 13 - Logout and Register ](https://github.com/codewithrafiq/Django-Reactjs-Online-Shopping-App/tree/5c7361c6077051aeedcd6a5f262159a0c9c36b7c)
